package com.ust.utilities;

public class Constants {

}
