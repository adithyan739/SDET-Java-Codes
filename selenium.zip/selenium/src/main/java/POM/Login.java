package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login {
	WebDriver driver;
	public Login(WebDriver driver) {
		this.driver=driver;
	}
	//locators
	By username=By.name("user");
	By password=By.name("pass");
	By submit=By.name("btnSubmit");
	/*
	<a id="header" class="heads">login</a>
	//a#header
	//a.heads
	//a[id='header']
	 */
	
	//elements as methods
	public void userName(String user) {
		
		WebElement uname=driver.findElement(username);
		if(uname.isEnabled()==true)
			uname.sendKeys(user);
	}
	
	public void passWord(String pass) {
		WebElement pword=driver.findElement(password);
		pword.sendKeys(pass);
	}
	
	public void submit() {
		WebElement submit_=driver.findElement(submit);
		submit_.click();
	}
}
