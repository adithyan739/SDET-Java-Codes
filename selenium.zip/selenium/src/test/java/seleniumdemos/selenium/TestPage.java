package seleniumdemos.selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class TestPage {
	
	WebDriver driver;
	@Test
	public void script() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://testpages.herokuapp.com/styled/index.html");
		driver.manage().window().maximize();
		
		driver.findElement(By.linkText("Alerts (JavaScript)")).click();
		driver.findElement(By.id("alertexamples")).click();
		Alert alert=driver.switchTo().alert();
		alert.accept();
		driver.findElement(By.id("promptexample")).click();
		Alert alert1=driver.switchTo().alert();
		alert1.sendKeys("hihello");
		//alert.accept();
		
		//alert.dismiss();
	}

}
