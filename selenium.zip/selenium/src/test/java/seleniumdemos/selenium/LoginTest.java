package seleniumdemos.selenium;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginTest {
	
	WebDriver driver;
	
	
	@BeforeClass
	public void init() throws InterruptedException {
		driver = new EdgeDriver();
		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.navigate().to("https://opensource-demo.orangehrmlive.com");
		Thread.sleep(5000);
	}
	
	@Test(priority = 1,enabled = false)
	public void invalidLoginTest() {
		
		
		driver.findElement(By.name("username")).sendKeys("sam");
		driver.findElement(By.name("password")).sendKeys("sam");
		driver.findElement(By.xpath("//button")).click();
		
		WebElement errorMsg = driver.findElement(By.xpath("//div[@class='orangehrm-login-form']/div/div/div/p"));
		
		assertTrue(errorMsg.isDisplayed());
		
		assertEquals(errorMsg.getText(), "Invalid credentials");
		
		
		
	}
	
	@Test(priority = 2)
	public void validLoginTest() throws InterruptedException {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button")).click();
		//Thread.sleep(30000);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span/i0")));
		
		driver.findElement(By.xpath("//span/i")).click();
		driver.findElement(By.xpath("//li/ul/li[4]/a")).click();
		
		assertEquals(driver.getCurrentUrl(),"https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}
	
	
	@AfterClass
	public void des() {
		driver.close();
	}

}



