package seleniumdemos.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class BrowserDef {
	
	WebDriver driver;
	@Test
	public void getBrowser() {
		
		//options.addArguments("--remote-allow-origins+*");
		//WebDriver driver = new ChromeDriver();
		//if edge->webdriver d=new EdgeDriver();
		
		driver=BrowserConfig.getBrowser();
		driver.get("https://www.google.com");          //navigate to website
		
		//to maximize the window
		driver.manage().window().maximize();
		//driver.get("https://www.flipkart.com");
		driver.navigate().to("https://www.amazon.in"); //navigate to website
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
		
		String title=driver.getTitle();
		String url=driver.getCurrentUrl();
		
	}
}
