package seleniumdemos.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class AmazonAuto {
	
	WebDriver driver;
	@Test
	public void amazon() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.amazon.in");
		driver.manage().window().maximize();
	//	driver.findElement(By.linkText("Account & Lists")).click();
		
		WebElement src=driver.findElement(By.className("nav-line-1-container"));
		Actions a=new Actions(driver);
		a.moveToElement(src).perform();
		WebElement ac=driver.findElement(By.linkText("Sign in"));
		a.moveToElement(ac).click().perform();
		driver.findElement(By.id("ap_email")).click();
		driver.findElement(By.id("ap_email")).sendKeys("adithyan@gmail.com");
		driver.findElement(By.id("continue")).click();
		driver.findElement(By.id("ap_password")).sendKeys("adithyan0007");
		driver.findElement(By.id("signInSubmit")).click();
	
	}
}
