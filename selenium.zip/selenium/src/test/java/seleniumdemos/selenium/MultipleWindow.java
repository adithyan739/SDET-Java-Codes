package seleniumdemos.selenium;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.xml.transform.stax.StAXSource;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class MultipleWindow {
	
	WebDriver driver;
	@Test
	public void multiple() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		
		driver.findElement(By.linkText("Open New Seperate Windows")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		Set<String> windows=driver.getWindowHandles();
		System.out.println(windows.size());
		
		List<String> winlist=new ArrayList<>(windows);
		
		driver.switchTo().window(winlist.get(1));
		WebElement src=driver.findElement(By.xpath("/html/body/div/main/section[1]/div/div/div/h1"));
		System.out.println(src.getText());
		
		driver.switchTo().window(winlist.get(0));
		WebElement src1=driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/h1"));
		System.out.println(src1.getText());
	}

}
