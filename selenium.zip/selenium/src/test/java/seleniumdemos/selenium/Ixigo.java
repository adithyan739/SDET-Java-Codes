package seleniumdemos.selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class Ixigo {
	
	WebDriver driver;
	@Test
	public void ixigo() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.ixigo.com/");
		driver.manage().window().maximize();
		
		//driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[1]/div[5]/div/div/div[1]/div/div[1]/input")).clear();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//		driver.findElement(By.xpath("(//div[@class='c-input u-v-align-middle'])[1]")).clear();
//		WebElement fromElement=driver.findElement(By.xpath("(//div[@class='c-input u-v-align-middle'])[1]"));
//		WebElement fromElement=driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[1]"));
		WebElement fromElement=driver.findElement(By.xpath("//div[@class='orgn u-ib u-v-align-bottom u-text-left']//input"));

//		WebDriverWait wait =new WebDriverWait(driver, Duration.ofSeconds(10));
//		wait.until(ExpectedConditions.visibilityOf(fromElement));
		fromElement.click();
		fromElement.sendKeys("TRV - Trivandrum");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ENTER);
//		fromElement.sendKeys(Keys.ENTER);
		
		WebElement toelement=driver.findElement(By.xpath("//div[@class='dstn u-ib u-v-align-bottom u-text-left']//input"));
		toelement.sendKeys("COK - Kochi");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ENTER);
		
		//COK - Kochi
		//wait.until(ExpectedConditions.visibilityOf(fromElement));
		
//		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[1]/div[5]/div/div/div[1]/div/div[1]/input")).sendKeys("TRV - Trivandrum");
//		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[1]/div[5]/div/div/div[3]/div/div[1]/input")).sendKeys("COK - Kochi");
//		driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[1]/div[5]/div/div/div[4]/div/div[1]/div/input")).click();
//		driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/table/tbody/tr[6]/td[1]/div[1]")).click();
	}

}
