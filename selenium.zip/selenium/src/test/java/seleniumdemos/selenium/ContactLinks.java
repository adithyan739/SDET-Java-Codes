package seleniumdemos.selenium;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class ContactLinks {
	
	WebDriver driver;
	@Test
	public void contactlinks() throws IOException {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.mycontactform.com");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Sample Forms")).click();
//		TakesScreenshot src1= (TakesScreenshot) driver;	
//		List<WebElement> links=driver.findElements(By.xpath("//div[@id='left_col_top']//ul//li//a"));
//		
//			
//		for(int i=0;i<links.size();i++) {
//			List<WebElement> links1=driver.findElements(By.xpath("//div[@id='left_col_top']//ul//li//a"));
//			links1.get(i).click();
//			File src2=src1.getScreenshotAs(OutputType.FILE);
//			FileUtils.copyFile(src2, new File("‪C:\\JavaCodes\\selenium\\src\\test\\java\\seleniumdemos\\selenium\\Screenshots\\aa"+i+".jpg"));
//		}
		
		List<WebElement> l=driver.findElements(By.xpath("//div[@id='left_col_top']//ul//li//a"));
		TakesScreenshot src1=(TakesScreenshot) driver;
		for(int i=0;i<l.size();i++)
		{
		List<WebElement> l2=driver.findElements(By.xpath("//div[@id='left_col_top']//ul//li//a"));
		l2.get(i).click();
		File src2=src1.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src2, new File("C:\\Users\\248961\\Documents\\Screenshots\\aa"+i+".jpg"));

		}
	}
}


