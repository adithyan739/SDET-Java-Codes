package seleniumdemos.selenium;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class SynchronizeTest {
	//http://www.uitestingplayground.com/
	WebDriver driver;
	@Test
	public void syncronize(){
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("http://www.uitestingplayground.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id=\"overview\"]/div/div[2]/div[1]/h3/a")).click();
		driver.findElement(By.xpath("//*[@id=\"ajaxButton\"]")).click();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(20));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.className("bg-success")));
		WebElement src=driver.findElement(By.className("bg-success"));
		String txt=src.getText();
		System.out.println(txt);
	}

}
