package seleniumdemos.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class MouseHover {
	WebDriver driver;
	@Test
	public void hoverChart() {
		driver = BrowserConfig.getBrowser();
		driver.navigate().to("https://clarle.github.io/yui3/yui/docs/charts/charts-pie.html");
		driver.manage().window().maximize();
		
		WebElement mh=driver.findElement(By.xpath("//*[contains(@id,'yui_3_17_2_1_16902')][contains(@class,'yui3-shape yui3')][@fill='#e8cdb7']"));
		Actions actions = new Actions(driver);
		actions.moveToElement(mh).perform();
		
		//WebElement mh1=driver.findElement(By.xpath("//*[contains(@id,'yui_3_17_2_1_1690258130309_21_0_0')][contains(@class,'yui3-shape yui3-svgShape yui3-svgPieSlice yui3-svgSvgPieSlice yui3-seriesmarker')][@fill='##66007f']"));
		//Actions actions = new Actions(driver);
		//actions.moveToElement(mh1).perform();
	
		
		
	}

}
