package seleniumdemos.selenium;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class AmazonSearch {
	
	WebDriver driver;
	@Test
	public void amazon() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("http://www.amazon.com/");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("JBL Speaker");
		driver.findElement(By.id("nav-search-submit-button")).click();
		
		driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']")).click();
		driver.findElement(By.xpath("//a[@id='s-result-sort-select_1']")).click();
		//driver.findElement(By.xpath("//*[@id=\"p_89/JBL\"]/span/a/div/label/i")).click();
		//List<WebElement> l=driver.findElements(By.xpath("//h2[contains(@class,'a-size-mini a')]//a//span"));
		
		//WebElement w=driver.findElement(By.xpath("//h2[contains(@class,'a-size-mini a')]//a//span"));
		//List<WebElement> list=new ArrayList<>();
//		for(int i=0;i<5;i++)
//		{
//			System.out.println(l.get(i).getText());
//		}
		
		List<WebElement> j=driver.findElements(By.xpath("//h2[contains(@class,'a-size-mini a-spacing')]//a/span"));
		for (int i = 0; i < 5; i++) {
		System.out.println(j.get(i).getText());
		}
		driver.close();
	}

}
