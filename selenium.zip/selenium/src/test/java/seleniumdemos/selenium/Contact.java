package seleniumdemos.selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class Contact {
	
	WebDriver driver; 
	@Test
	public void mycontact() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.mycontactform.com");
		driver.manage().window().maximize();
		
		driver.findElement(By.linkText("Sample Forms")).click();
		
		List<WebElement> links=driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		
		for(int i=0;i<links.size();i++) {
			System.out.println(links.get(i).getAttribute("href"));
		}
		
		
		
	}

}
