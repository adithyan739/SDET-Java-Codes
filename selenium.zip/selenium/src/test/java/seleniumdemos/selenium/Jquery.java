package seleniumdemos.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class Jquery {
	
	WebDriver driver;
	@Test
	public void jquery() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.jqueryui.com");
		driver.manage().window().maximize();
		driver.findElement(By.id("Droppable")).click();
		WebElement element=driver.findElement(By.className("demo-frame"));
		driver.switchTo().frame(element);
		
		WebElement src=driver.findElement(By.id("draggable"));
		WebElement dest=driver.findElement(By.id("droppable"));
		Actions a=new Actions(driver);
		a.clickAndHold(src).moveToElement(dest).release(dest).build().perform();
		
		
		
	}

}
