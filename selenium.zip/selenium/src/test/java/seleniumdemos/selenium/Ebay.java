package seleniumdemos.selenium;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class Ebay {
	
	WebDriver driver;
	

	@BeforeClass
	public void init() throws InterruptedException {
		driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.navigate().to("https://www.ebay.com");
		Thread.sleep(5000);
	}
	
	@Test
	public void ebay() throws InterruptedException {
		
		driver.findElement(By.xpath("//input[@class='gh-tb ui-autocomplete-input']")).sendKeys("adidas shoes");
		driver.findElement(By.id("gh-btn")).click();
		driver.findElement(By.linkText("Buy It Now")).click();
		driver.findElement(By.xpath("/html/body/div[5]/div[4]/div[1]/div[2]/div[1]/div[3]/div[1]/div/span/button")).click();
		driver.findElement(By.xpath("/html/body/div[5]/div[4]/div[1]/div[2]/div[1]/div[3]/div[1]/div/span/span/ul/li[3]/a/span")).click();
		
		WebElement src=driver.findElement(By.xpath("//*[@id=\"item52a37c5ef4\"]/div/div[2]/div[3]/span[1]/span/span"));
		String s=src.getText();

		Assert.assertEquals(s, "Jul-21 04:08");
		
		//driver.findElement(By.xpath("//*[@id=\"nid-gv7-1\"]/button")).click();
		//Thread.sleep(3000);
		//driver.findElement(By.xpath("//*[@id=\"nid-vk5-1\"]")).click();
		
//		driver.findElement(By.xpath("//*[@id=\"s0-53-17-5-4[1]-73-37-1-content-menu\"]/li[3]/a/span/text()")).click();
//		Select s2=new Select(we);
//		s2.selectByVisibleText("Time: newly listed");
		
	}
}
