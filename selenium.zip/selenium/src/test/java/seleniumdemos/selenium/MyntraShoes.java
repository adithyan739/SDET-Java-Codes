package seleniumdemos.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class MyntraShoes {
	
	WebDriver driver;
	@Test
	public void myntra() {
		driver = BrowserConfig.getBrowser();
		driver.navigate().to("https://www.Ajio.com/");
		driver.manage().window().maximize();
		
		WebElement wb= driver.findElement(By.xpath("//li//a[@href='/shop/men']"));
		Actions actions = new Actions(driver);
		actions.moveToElement(wb).perform();
		driver.findElement(By.xpath("//span//a[@href='/men-casual-shoes/c/830207006']")).click();
		//div[@class='facet-head facet-xpndicon']//span[@class='facet-left-pane-label'])[3]
		//driver.findElement(By.xpath("(//div[@class='facet-head facet-xpndicon']//span[@class='facet-left-pane-label'])[3]")).click();
		driver.findElement(By.xpath("//*[@id=\"facets\"]/div[2]/ul/li[4]/div/div/div/span[2]")).click();
		driver.findElement(By.xpath("//div[@id='verticalsizegroupformat']")).click();
		//U.S. Polo Assn.
		driver.findElement(By.xpath("//*[@id=\"modalId\"]/div/div/form/div/div[2]/ul[22]/li[4]/div/label/span/span[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"modalId\"]/div/div/form/div/div[3]/div/button[3]")).click();
	}

}
