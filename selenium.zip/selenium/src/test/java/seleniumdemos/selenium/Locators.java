package seleniumdemos.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class Locators {
	
	WebDriver driver;
	@Test
	public void locators() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.mycontactform.com");
		driver.manage().window().maximize();
		//driver.findElement(By.linkText("Sample Forms")).click();
		WebElement link=driver.findElement(By.linkText("Sample Forms"));
		link.click();
		driver.findElement(By.id("subject")).sendKeys("Adhi");
		driver.findElement(By.id("email")).sendKeys("adithyan@gmail.com");
		driver.findElement(By.id("q1")).sendKeys("Adithyakumar");
		driver.findElement(By.id("q2")).sendKeys("Hello Adhi");
		//driver.findElement(By.xpath("//input[@name='email_to[]'][@value='1']")).click();
		driver.findElement(By.xpath("//input[@name='email_to[]'][2]")).click();
		WebElement we=driver.findElement(By.id("q3"));
		Select s=new Select(we);
		s.selectByIndex(1);
		//s.selectByValue("Fourth Option");
		//s.selectByVisibleText("Third Option");
		driver.findElement(By.xpath("//input[@name='q4'][2]")).click();
		driver.findElement(By.xpath("//input[@id='q5']")).click();
		driver.findElement(By.xpath("//input[@name='checkbox6[]'][2]")).click();
		driver.findElement(By.xpath("//input[@name='checkbox6[]'][3]")).click();
		driver.findElement(By.id("q7")).sendKeys("01-02-1999");
		WebElement we1=driver.findElement(By.id("q8"));
		Select s1=new Select(we1);
		s1.selectByValue("CA");
		WebElement we2=driver.findElement(By.id("q9"));
		Select s2=new Select(we2);
		s2.selectByValue("India");
		WebElement we3=driver.findElement(By.id("q10"));
		Select s3=new Select(we3);
		s3.selectByValue("Ontario");
		WebElement we4=driver.findElement(By.name("q11_title"));
		Select s4=new Select(we4);
		s4.selectByValue("Mr.");
		driver.findElement(By.name("q11_first")).sendKeys("Adithyakumar");
		driver.findElement(By.name("q11_last")).sendKeys("K S");
		WebElement we5=driver.findElement(By.name("q12_day"));
		Select s5=new Select(we5);
		s5.selectByValue("7");
		WebElement we6=driver.findElement(By.name("q12_month"));
		Select s6=new Select(we6);
		s6.selectByValue("3");
		WebElement we7=driver.findElement(By.name("q12_year"));
		Select s7=new Select(we7);
		s7.selectByValue("1999");
		driver.findElement(By.id("attach4589")).sendKeys("C:\\Users\\248961\\Downloads\\image.png");
		driver.findElement(By.id("visver_code")).sendKeys("FFEABD");
		driver.findElement(By.name("submit")).click();
	}

}
