package seleniumdemos.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class Myntra {
	
	WebDriver driver;
	@Test
	public void myntra() {
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.myntra.com/");
		driver.manage().window().maximize();
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,5000)","");
//		WebElement src=driver.findElement(By.xpath(""));
//		js.executeScript("arguments[0].click()",WebElement);
		
	}

}
