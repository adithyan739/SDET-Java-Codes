package seleniumdemos.selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Base.BrowserConfig;

public class CalenderTest {

	WebDriver driver;

	@Test
	public void calender() throws InterruptedException {

		driver = BrowserConfig.getBrowser();
		driver.navigate().to("https://www.ixigo.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		WebElement fromElement = driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[1]"));
		// WebDriverwait wait=new WebDriverwait(driver,Duration.ofSeconds(10));
		fromElement.click();
		fromElement.sendKeys("MAA-Chennai");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ENTER);
		// fromElement.sendKeys("");
		WebElement fromElement1 = driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[2]"));
		// WebDriverwait wait=new WebDriverwait(driver,Duration.ofSeconds(10));
		fromElement1.click();
		fromElement1.sendKeys("HYD-Hyderabad");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ENTER);
		WebElement da = driver.findElement(By.xpath("(//input[@class='c-input u-v-align-middle'])[3] "));
		da.click();
		String s = "November";
		// WebElement d4=
		// driver.findElement(By.xpath("(//div[@class='rd-month-label'])[2]"));
		// String b=d4.getText();
		// String arr1[]=b.split(" ");
		for (int i = 0; i < 12; i++) {
			WebElement d = driver.findElement(By.xpath("(//div[@class='rd-month-label'])[1]"));
			String a = d.getText();
			String arr[] = a.split(" ");
			if (((arr[0].equals(s)))) {
				break;
			} else {
				WebElement m = driver.findElement(By.xpath("//button[@class='ixi-icon-arrow rd-next']"));
				Thread.sleep(3000);
				m.click();
			}
		}
	}
}