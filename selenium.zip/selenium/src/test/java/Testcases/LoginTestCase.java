package Testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.BrowserConfig;
import POM.Login;

public class LoginTestCase {
	WebDriver driver;
	@BeforeTest
	public void setup() {
		driver=BrowserConfig.getBrowser();	
		driver.navigate().to("https://www.mycontactform.com");
	}
	
	@Test(priority=0)
	public void usernameTest() {
		Login login=new Login(driver);
		login.userName("admin");	
	}
	
	@Test(priority=1)
	public void passwordTest() {
		Login login=new Login(driver);
		login.passWord("admin123");
	}
	
	@Test(priority=2)
	public void submitTest() {
		Login login=new Login(driver);
		login.submit();
		
	}
	
	@AfterTest
	public void teardown() {
		driver.close();
	}

}
