package POM;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import Base.BaseUI;

public class SwagLabs extends BaseUI{
	WebDriver driver;

	public SwagLabs(WebDriver driver) {
		this.driver = driver;
	}

	By username = getlocator("username_name");
	By password = getlocator("password_name");
	By submit = getlocator("submit_name");


	By rslt1 = getlocator("rslt1_xpath");
	By rslt2 = getlocator("rslt2_xpath");
	By add_cart1 = getlocator("add_cart_onesie_name");
	By add_cart2 = getlocator("add_cart_light_name");
	By cart_btn = getlocator("cart_button_xpath");
	
	By logout = getlocator("logout_linkText");

	// elements as methods
	public void userName(String user) {
		sendtext(username, user);
		logger.log(Status.INFO, "username is entered");
	}

	public void passWord(String pass) {
		isElementPresent(password, Duration.ofSeconds(15));
		sendtext(password, pass);
		logger.log(Status.INFO, "password is entered");
	}

	public void submit() {
		clickOn(submit);
		logger.log(Status.INFO, "submit is clicked");
	}

	public String getURL() {
		String url = driver.getCurrentUrl();
		return url;
	}

	public String getrslt1() {
		return gettext(rslt1);
	}

	public String getrslt2() {
		return gettext(rslt2);

	}

	public void addto_cart1() {
		clickOn(add_cart1);
	}

	public void addto_cart2() {
		clickOn(add_cart2);
	}

	public void cart_button() {
		clickOn(cart_btn);
	}

	public void logout_click() {
		clickOn(logout);
	}
}
