package Utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtilities {
	public static String[][] testdata() {

		FileInputStream fis;
		XSSFWorkbook workbook = null;
		try {
			fis = new FileInputStream("C:\\JavaCodes\\saucedemo\\ExcelFiles\\Book1.xlsx");
			workbook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rowcount = sheet.getPhysicalNumberOfRows();
		int colcount = sheet.getRow(0).getPhysicalNumberOfCells();
		String[][] testdata = new String[rowcount][colcount];
		for (int i = 0; i < rowcount; i++) {
			for (int j = 0; j < colcount; j++) {
				testdata[i][j] = sheet.getRow(i).getCell(j).getStringCellValue();
			}
		}
		return testdata;
	}

	public static void main(String[] args) {

		String arr[][] = testdata();

		for (int i = 0; i < arr.length; i++) {

			for (int j = 0; j < arr[0].length; j++) {

				System.out.println(arr[i][j]);

			}

		}

	}
}
