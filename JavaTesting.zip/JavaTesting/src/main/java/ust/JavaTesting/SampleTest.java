package ust.JavaTesting;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;


public class SampleTest {
	
	@Test
	public void demoTestMethod() {
		assertTrue(true);
		assertEquals(25, 23+2);
	}

}
