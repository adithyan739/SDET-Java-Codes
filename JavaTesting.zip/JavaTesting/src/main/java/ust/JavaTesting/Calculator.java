package ust.JavaTesting;

public class Calculator {
	public int multiply(int a,int b) {
		return a*b;
	}

}
