package ust.JavaTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CalculatorTest {
	
	@Test
	public void testmultiply() {
		Calculator calculator=new Calculator();
		assertEquals(20, calculator.multiply(4, 5),"Regular mulplication should work");
	}

	@Test
	public void testmultiplication() {
		Calculator calculator=new Calculator();
		assertEquals(0, calculator.multiply(0, 3),"Multiply with zero should be zero");
	}
}
