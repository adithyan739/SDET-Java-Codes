package api.test.testAPI;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.CoreMatchers.equalTo;

public class AppTest 
{

    @Test
    public void automateGetRequest()
    {
       int bookingid = given().
    		baseUri("http://restful-booker.herokuapp.com").contentType("application/json").
       when().
       		get("/booking").
       then().extract().response().path("bookingid[0]");
       
       System.out.println(bookingid);
       assertThat(bookingid,equalTo(964));//assert using hamcrest
       //Assert.assertEquals(bookingid,964);//assert using testNG
       
    }
    
    @Test
    public void automatePostRequest() {
    	String getToken;
    	String payload="{\n"+"\"username\":\"admin\",\n"+
    					"\"password\":\"password123\"\n"+
    					"}";
    	Response response=given().
    			baseUri("http://restful-booker.herokuapp.com").
    			contentType("application/json").
    			body(payload).
    			when().
    				post("/auth").
    			then().
    				log().all().
    				extract().
    				response();
    	getToken=response.jsonPath().getString("token");
    	System.out.println(getToken);
    }
}
