package endpoints;

public class Routes {
	public static String baseuri="https://petstore.swagger.io/v2";
	public static String post_basePath="/user";
	public static String get_basePath="/user/{username}";
	public static String delete_basePath="user/{username}";
	public static String update_basePath="user/{username}";

}
