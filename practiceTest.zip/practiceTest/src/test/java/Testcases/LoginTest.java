package Testcases;

import java.time.Duration;
import java.io.IOException;
import java.time.Duration;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base.BaseUI;
import Base.BrowserConfig;
import ExcelUtilities.ExcelUtilities;
import POM.Login;
import POM.WelcomePage;

public class LoginTest extends BaseUI {
	private WebDriver driver;
	String[][] data;

	@BeforeMethod
	public void setUp() {
// Set the path of the ChromeDriver executable
//		driver = BrowserConfig.getchromeBrowser();
//		driver.navigate().to("https://practicetestautomation.com/practice-test-login/");
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver = invokebrowser();
		openBrowser("applicationURL");
	}

	@DataProvider(name = "testData")
	public Object[][] testdata() throws IOException {
		data = ExcelUtilities.testdata();
		return data;
	}

	@Test(priority = 1, dataProvider = "testData")
	public void loginTest(String username, String password, String expectedtext) {
		Login login = new Login(driver);
		login.userName(username);
		login.passWord(password);
		login.submit();
		WelcomePage wlcm = new WelcomePage(driver);

		String a = wlcm.getURL();

		//String j = login.geterrormsg();
		if (username.equals("incorrectUser")) {

			SoftAssertions.assertSoftly(softAssertions -> {

				softAssertions.assertThat(login.geterrormsg().equalsIgnoreCase("Your username is invalid!"));

			});

		} else if (password.equals("incorrectPassword")) {

			SoftAssertions.assertSoftly(softAssertions -> {

				softAssertions.assertThat(login.geterrormsg().equalsIgnoreCase("Your password is invalid!"));

			});

		} else {

			String p = (String) wlcm.getrslt();

			String value = "Congratulations student. You successfully logged in!";

			SoftAssertions.assertSoftly(softAssertions -> {

				softAssertions.assertThat(a.contains("practicetestautomation.com/logged-in-successfully/"));

				softAssertions.assertThat(p.equalsIgnoreCase(value));

				softAssertions.assertThat(

						driver.findElement(By.xpath("//a[contains(@class,'wp-block-button__link has-text-color')]"))

								.isDisplayed());

			});

		}

	}
//
//	@Test(dataProvider = "testData")
//	public void negativeUsernameTest(String username, String password) {
//		// login(username, password);
//		Login login = new Login(driver);
//		login.userName(username);
//		login.passWord(password);
//		login.submit();
//// Verify error message is displayed
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("//div[@id='error']")).isDisplayed());
//// Verify error message text is Your username is invalid!
//		});
//// Verify error message text is Your username is invalid!
//		Assertions.assertThat(driver.findElement(By.xpath("//div[@id='error']")).getText())
//				.isEqualTo("Your username is invalid!");
//	}
//
//	@Test(dataProvider = "testData")
//	public void negativePasswordTest(String username, String password) {
//		// login(username, password);
//		Login login = new Login(driver);
//		login.userName(username);
//		login.passWord(password);
//		login.submit();
//// Verify error message is displayed
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("//div[@id='error']")).isDisplayed());
//// Verify error message text is Your password is invalid!
//		});
//		Assertions.assertThat(driver.findElement(By.xpath("//div[@id='error']")).getText())
//				.isEqualTo("Your password is invalid!");
//	}

//	@AfterTest
//	public void tearDown() {
//		driver.quit();
//	}

//	public void login(String username, String password) {
//		driver.findElement(By.id("username")).sendKeys(username);
//		driver.findElement(By.id("password")).sendKeys(password);
//		driver.findElement(By.id("submit")).click();
//	}

}