package POM;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import Base.BaseUI;

public class WelcomePage extends BaseUI {

	WebDriver driver;

	public WelcomePage(WebDriver driver) {

		this.driver = driver;

	}

	By rslt = getlocator("rslt_xpath");

	By logout = getlocator("logout_xpath");

	public void clicklogout() {

		clickOn(logout);

	}

	public String getrslt() {

		return getText(rslt);

	}

	public String getURL() {

		String url = driver.getCurrentUrl();

		return url;

	}

}
