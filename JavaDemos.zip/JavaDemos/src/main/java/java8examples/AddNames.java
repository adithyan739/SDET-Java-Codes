package java8examples;

import java.util.ArrayList;
import java.util.Scanner;

public class AddNames {
	public static void main(String[] args) {
		ArrayList<String> arr=new ArrayList<>();
		Scanner s=new Scanner(System.in); 
		int n=s.nextInt();
		for(int i=0;i<n;i++) {
			arr.add(s.next());
		}
//		for(int i=0;i<n;i++) {
//			System.out.println(arr.get(i));
//		}
		
		arr.forEach(element->System.out.println(element));
		
		//reverse names using lambda
		arr.forEach(name->{
			String reversed=new StringBuffer(name).reverse().toString();
			System.out.println(reversed);
		});
		//reverse names using method reference
		arr.replaceAll(AddNames::reverseString);
		arr.forEach(System.out::println);
	}
	private static String reverseString(String s) {
		return new StringBuffer(s).reverse().toString();
	}
}
