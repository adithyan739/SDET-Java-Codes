package java8examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Alphabets {
	public static void main(String[] args) {
		List<String> alpha=Arrays.asList("a","b","c","d","e");
		//List<Character> result=c.stream().filter(element->element.toUpperCase(c).collect(Collectors.toList());
		List<String> alphaupper=new ArrayList<>();
		for(String s:alpha) {
			alphaupper.add(s.toUpperCase());
		}
		System.out.println(alpha);
		System.out.println(alphaupper);
		
		List<String> collect=alpha.stream()
				.map(String::toUpperCase)
				.collect(Collectors.toList());
		System.out.println(collect);
		
		List<Integer> num=Arrays.asList(23,11,10,15);
		List<Integer> collect1=num.stream()
				.map(n->n*2)
				.collect(Collectors.toList());
		System.out.println(collect1);
		
	}

}
