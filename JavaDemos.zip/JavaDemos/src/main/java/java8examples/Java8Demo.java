package java8examples;

public class Java8Demo {

}
