package java8examples;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class SeriesProductTest {
	
	@Test
	public void SeriesProduct() {
		
		long str=SeriesProduct.calculateSeries("63915",3);
		assertEquals(162,str);
	}

}
