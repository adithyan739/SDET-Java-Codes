package java8examples;

/*Interface that contain a single abstract method
 * along with SAM,FIs can have multiple default methods
 * default methods-they can overridden
 * static methods-methods in interface having implementation,
 * these can be used in implementing class but cannot be overriden
 * */

@FunctionalInterface
public interface AddNumbers {
	int addition(int a, int b);

}
