package java8examples;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class BeforeJava8 {
	public static void main(String[] args) {
		List<Person> persons=Arrays.asList(
				new Person("Akshai",30),
				new Person("Shammi",28),
				new Person("Adhi",26));
		
		Person result=getStudentByname(persons,"Adhi");
		System.out.println(result);
		
		//affter java 8
		Person result1=persons.stream()
				.filter(temp->"Adhi".equals(temp.getName()))
				.findAny()
				.orElse(null);
		System.out.println(result1);
		
		Person result2=persons.stream()
				.filter(temp->"Shammi".equals(temp.getName())&&28==temp.getAge())
				.findAny()
				.orElse(null);
		System.out.println(result2);
		
		List<String> result3=persons.stream()
				.map(names->names.getName())
				.collect(Collectors.toList());
		System.out.println(result3);
		
	}

	
	//before java 8
	private static Person getStudentByname(List<Person> persons,String name) {
		Person result=null;
		for(Person temp:persons) {
			if(name.equals(temp.getName())) {
				result=temp;
			}
		}
		return result; 
}
}
