package java8examples;

import java.util.Scanner;

public class SeriesProduct {
	public static long calculateSeries(String str,int span) {
		long maxProduct=0;
		//int[] num=new int[str.length()];
		//int prod=1;
		for(int i=0;i<=str.length()-span;i++) {
			String series=str.substring(i,i+span);
			long product=1;
			//num[i]=str.charAt(i);
			for(int j=i;j<series.length();j++) {
				product*=Character.getNumericValue(series.charAt(j));
			}
			maxProduct=Math.max(maxProduct, product);
		}
		
		
		return maxProduct;
	}
//	
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		String str=sc.nextLine();
//		int span=3;
//		System.out.println(calculateSeries(str,span));
//		
//	}

}
