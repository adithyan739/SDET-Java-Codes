package java8examples;

import java.util.Scanner;

public class ScrabbleScore {
	public static int scrabble(String str) {
		int score=0;
		String s=str.toUpperCase();
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='A' || s.charAt(i)=='E'||s.charAt(i)=='I'||s.charAt(i)=='O'||s.charAt(i)=='U'
					||s.charAt(i)=='L'||s.charAt(i)=='N'||s.charAt(i)=='R'||s.charAt(i)=='S'||s.charAt(i)=='T') {
				score+=1;
			}
			else if(s.charAt(i)=='D'||s.charAt(i)=='G') {
				score+=2;
			}
			else if(s.charAt(i)=='B'||s.charAt(i)=='C'||s.charAt(i)=='M'||s.charAt(i)=='P') {
				score+=3;
			}
			else if(s.charAt(i)=='F'||s.charAt(i)=='H'||s.charAt(i)=='V'||s.charAt(i)=='W'||s.charAt(i)=='Y') {
				score+=4;
			}
			else if(s.charAt(i)=='K') {
				score+=5;
			}
			else if(s.charAt(i)=='J'||s.charAt(i)=='X') {
				score+=8;
			}
			else if(s.charAt(i)=='Q'||s.charAt(i)=='Z') {
				score+=10;
			}
		}
		return score;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		System.out.println(scrabble(str));
	}
}
