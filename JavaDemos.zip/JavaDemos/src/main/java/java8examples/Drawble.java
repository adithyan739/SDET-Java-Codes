package java8examples;

public interface Drawble {
	public void msg(String msg);

}
