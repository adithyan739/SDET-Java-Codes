package java8examples;

public class BrowserMainMethod {

}
