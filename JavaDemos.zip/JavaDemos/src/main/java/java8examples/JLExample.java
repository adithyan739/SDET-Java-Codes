package java8examples;

public class JLExample {
	
	//without lambda
	
//	Drawble d=new Drawble() {
//		
//		@Override
//		public void msg(String msg) {
//			// TODO Auto-generated method stub
//			System.out.println(msg);
//		}
//	};
//	public static void main(String[] args) {
//		d.msg("Hi");
//	}
	
	
//	public static void main(String[] args) {
//		
//		//with lambda expression
//		Drawble withlambda=(msg)->{System.out.println(msg);};
//		withlambda.msg("Hello");
//	}

}
