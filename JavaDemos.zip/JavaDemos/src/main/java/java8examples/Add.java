package java8examples;

public interface Add {

	public int add(int a,int b);
}
