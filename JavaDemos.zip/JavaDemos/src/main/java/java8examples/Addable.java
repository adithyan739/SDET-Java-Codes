package java8examples;

public class Addable {
	public static void main(String[] args) {
		Add withlambda=(a,b)->{
			System.out.println("num1:"+a+" num2:"+b);
			return (a+b);};
			System.out.println(withlambda.add(5, 6));
			
			//multiple parameters inlambda expression
			Add withlambdb=(a,b)->a+b;
			System.out.println(withlambdb.add(5, 6));
			
			Add withlambdc=(int a, int b)->a+b;
			System.out.println(withlambdc.add(5, 6));
		}
	}


