package java8examples;

import java.util.ArrayList;
import java.util.Scanner;

public class MethodReferences {
	public static void main(String[] args) {
	Scanner s=new Scanner(System.in); 
	int n=s.nextInt();
	ArrayList<Integer> arr=new ArrayList<>();
	for(int i=0;i<n;i++) {

		arr.add(s.nextInt());
	}
	for(int i=0;i<n;i++) {

		System.out.println(arr.get(i)*5);
	}
	
	//printing elements using lambda
	arr.forEach(element->System.out.println(element));
	
	//printing even numbers using lambda
	arr.forEach(element->{
		if(element%2==0) {
			System.out.println(element);
		}
	});
	
	//printing elements using method reference
	arr.forEach(System.out::println);
	
	}
}
