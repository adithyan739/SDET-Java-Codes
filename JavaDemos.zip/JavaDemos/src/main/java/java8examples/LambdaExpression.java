package java8examples;

/**
 * Lambda expressions are means to create anonymous classes of FIs easily
 * 3 components- arguments list,arrow token(->) and body
 */

public class LambdaExpression implements AddNumbers{
	//implementation without lambda expression

//	@Override
//	public int addition(int a, int b) {
//		// TODO Auto-generated method stub
//		System.out.println("num1: "+a+" num2: "+b);
//		return a+b;
//	}
//	
//	public static void main(String[] args) {
//		int num1=15;
//		int num2=25;
//		LambdaExpression le=new LambdaExpression();
//		System.out.println(le.addition(num1, num2));
//	}

	//implementation using lambda expression
	public static void main(String[] args) {
		int num1=15;
		int num2=25;
		AddNumbers result=(n1,n2)->{return (n1+n2);};
		System.out.println(result.addition(num1, num2));
		
	}
}
