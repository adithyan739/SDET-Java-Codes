package java8examples;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ListAddNames {
	public static void main(String[] args) {
		List<String> arr=new ArrayList<>();
		arr.add("Adhi");
		arr.add("Shammi");
		arr.add("Yadu");
		arr.add("Nithil");
		List<String> names=arr.stream()
				.filter(n->n!="Adhi")
				.collect(Collectors.toList());
		names.forEach(System.out::println);
		
		
	}

}
