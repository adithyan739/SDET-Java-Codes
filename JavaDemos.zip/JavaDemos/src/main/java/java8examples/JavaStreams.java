package java8examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 *Stream API supports iteration of elements of collections,
 *where we can process these elements,
 *perform operations on them and store the output
 *
 * intermediate stream operation->return new stream
 * terminal->these give final output for stream
 */
public class JavaStreams {
	public static void main(String[] args) {
		List<String> names=new ArrayList<>();
		names.add("Adhi");
		names.add("Yadu");
		names.add("Nithil");
		names.add("Naina");
		names.add("Shyama");
		
		/**
		 * filter-will return stream of elements having last char as a
		 * sorted-will sort the stream in ascending order
		 * collect-will collect each elements of stream returned by sorted to
		 * */
		List<String> namesendswith_a=names.stream()
				.filter(name->name.charAt(name.length()-1)=='a')
				.sorted()
				.collect(Collectors.toList());
		namesendswith_a.forEach(System.out::println);
		
		List<String> namesstartswith_a=names.stream()
				.filter(name->name.charAt(0)=='A')
				.sorted()
				.collect(Collectors.toList());
		namesstartswith_a.forEach(System.out::println);
		
		List<Integer> numbers=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		List<Integer> even_numbers=numbers.stream()
				.filter(number->number%2==0)
				.sorted()
				.collect(Collectors.toList());
		even_numbers.forEach(System.out::println);
		
	}

}
