package java8examples;

import java.util.Arrays;
import java.util.Scanner;

public class MinstoSeconds {
	public static int minutesToSeconds(String str) {
		String[] s=str.split(":");
		int result=0;
		int[] values=Arrays.stream(s)
				.mapToInt(Integer::parseInt)
				.toArray();
		if(values[1]>=60) {
			return -1;
		}
		else {
			result=values[0]*60+values[1];
		}
		return result;
		
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		System.out.println(minutesToSeconds(str));
	}

}
