package java8examples;

import java.time.LocalDateTime;
import java.time.LocalTime;

public class TimeDate1 {
	public static void main(String[] args) {
		LocalTime currTime=LocalTime.now();
		LocalTime t1=LocalTime.of(5, 32, 44);
		LocalTime t2=currTime.plusHours(2);
		LocalTime t3=currTime.plusMinutes(23);
		int hours=currTime.getHour();
		int minutes=currTime.getMinute();
		int seconds=currTime.getSecond();
		
		System.out.println(currTime);
		System.out.println(t1);
		System.out.println(t2);
		System.out.println(t3);
		System.out.println("Hours "+hours);
		System.out.println("Minutes "+minutes);
		System.out.println("Seconds "+seconds);
		
		LocalDateTime ldt=LocalDateTime.now();
		System.out.println(ldt);
	}

}
