package java8examples;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class DateDifference {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String date1=sc.next();
		String date2=sc.next();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate cdate1=LocalDate.parse(date1,formatter);
		LocalDate cdate2=LocalDate.parse(date2,formatter);
		long difference=ChronoUnit.DAYS.between(cdate1, cdate2);
		System.out.println(difference);
		
		
	}

}
