package java8examples;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class DateDemo {
	public static void main(String[] args) {
		LocalDate cdate=LocalDate.now();
		LocalDate pdate=LocalDate.parse("2023-07-05");
		System.out.println("Current date:"+cdate);
		System.out.println("Current date:"+pdate);
		
		LocalDate yesterday=cdate.minusDays(1);
		LocalDate tomorrow=cdate.plusDays(1);
		System.out.println("Yesterday's date:"+yesterday);
		System.out.println("Tomorrow's date:"+tomorrow);
		
		LocalDate cdate2=LocalDate.now();
		DayOfWeek dayofweek=cdate2.getDayOfWeek();
		int dayofmonth=cdate2.getDayOfMonth();
		int dayofyear=cdate2.getDayOfYear();
		
		System.out.println("day of week "+dayofweek);
		System.out.println("day of month "+dayofmonth);
		System.out.println("day of year "+dayofyear);
		
		/*cdate.isafter(yesterday)
		 * cdate.isbefore()
		 * cdate.isleapyear()
		 * cdate.lengthofmonth()
		 * cdate.lengthofyear()
		 * */
	}
}
