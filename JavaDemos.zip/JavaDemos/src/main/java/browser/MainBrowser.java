package browser;

import java.util.Scanner;

public class MainBrowser {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		if(str.equals("chrome")) {
			Google c=new Google();
			c.open();
			c.navigation();
			c.screenshot();
			c.close();
		}
		else if(str.equals("firefox")) {
			Mozilla f=new Mozilla();
			f.open();
			f.navigation();
			f.screenshot();
			f.close();
		}
		else if(str.equals("edge")) {
			Microsoft e=new Microsoft();
			e.open();
			e.navigation();
			e.screenshot();
			e.close();
		}
	}

}
