package browser;

public class Mozilla implements Browser,Screenshot {

	@Override
	public void screenshot() {
		// TODO Auto-generated method stub
		System.out.println("Screenshot taken in Mozilla Firefox");
	}

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Mozilla Firefox is opened");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println("Mozilla Firefox is closed");
	}

	@Override
	public void navigation() {
		// TODO Auto-generated method stub
		System.out.println("Navigating to Mozilla Firefox");
	}
	

}
