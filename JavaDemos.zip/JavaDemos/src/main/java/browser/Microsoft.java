package browser;

public class Microsoft implements Browser,Screenshot{

	@Override
	public void screenshot() {
		// TODO Auto-generated method stub
		System.out.println("Screenshot taken in Microsoft Edge");
	}

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Microsoft Edge is opened");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println("Microsoft Edge is closed");
	}

	@Override
	public void navigation() {
		// TODO Auto-generated method stub
		System.out.println("Navigating to Microsoft Edge");
	}

}
