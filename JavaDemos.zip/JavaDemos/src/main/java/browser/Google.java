package browser;

public class Google implements Screenshot,Browser {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Google Chrome is opened");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println("Google Chrome is closed");
	}

	@Override
	public void navigation() {
		// TODO Auto-generated method stub
		System.out.println("Navigating to Google Chrome");
	}

	@Override
	public void screenshot() {
		// TODO Auto-generated method stub
		System.out.println("Screenshot taken in Google Chrome");
		
	}
	

}
