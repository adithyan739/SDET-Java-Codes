package browser;

public interface Screenshot {
	public void screenshot();

}
