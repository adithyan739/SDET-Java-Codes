package browser;

public interface Browser {
	public void open();
	public void close();
	public void navigation();

}
