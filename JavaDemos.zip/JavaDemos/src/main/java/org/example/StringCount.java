package org.example;

import java.util.Scanner;

public class StringCount {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int counter[] = new int[256];
		System.out.println("Enter the String:");
		String str=s.nextLine();
//		String[] arr=str.split("\\s");
//		for(String w:arr){  
//			System.out.println(w);  
//			
//		}
		int length=str.length();
		for (int i = 0; i < length; i++) {
            counter[(int) str.charAt(i)]++;
        }
        for (int i = 0; i < 256; i++) {
            if (counter[i] != 0) {
                System.out.println((char) i + " --> " + counter[i]);
            }
        }
	}

}
