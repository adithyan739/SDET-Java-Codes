package org.example;

public class EvenSample {
	public static void main(String[] args) {
		int i=2;
		while(i<=30) {
			System.out.println(i);
			i=i+2;
		}
	}
}
