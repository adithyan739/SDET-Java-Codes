package org.example;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HashMapRemoveKeys {
	static int sizeOfResultandHashMap(int n) {
		Map<Integer,String> map=new HashMap<>(n);
		
		for(String keys:map.values()) {
			System.out.println(keys);
		}
		return map;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println(sizeOfResultandHashMap(n));
	}

}
