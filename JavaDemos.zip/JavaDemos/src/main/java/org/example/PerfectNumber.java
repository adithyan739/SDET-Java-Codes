package org.example;

public class PerfectNumber {

}
