package org.example;

public class MainSalary {
	public static void main(String[] args) {
		SalaryCalculator m=new Manager(30000, 1000);
		SalaryCalculator d=new Developer(25000, 2000);
		SalaryCalculator s=new SalesExecutive(20000, 1000);
		System.out.println(m.calculateSalary());
		System.out.println(d.calculateSalary());
		System.out.println(s.calculateSalary());
	}

}
