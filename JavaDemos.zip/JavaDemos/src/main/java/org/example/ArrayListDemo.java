package org.example;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.TreeSet;

public class ArrayListDemo {
	public static void main(String[] args) {
		//creation of arraylist
		ArrayList<Integer> a1=new ArrayList<>();
		//adding the elements into list
		a1.add(10);//autoboxing
		a1.add(20);
		a1.add(30);
		a1.add(40);
		a1.add(50);
		//inserting element into specified location
		a1.add(1, 77);
		//display the elements of list and its size
		System.out.println(a1);
		System.out.println("The size of list is:"+a1.size());
		
		//modifying the elements
		a1.remove(3);
		System.out.println(a1.get(0));
		for(int i=0;i<a1.size();i++) {
			System.out.println(a1.get(i));
		}
		Stack<Double> s=new Stack<>() ;
			s.push(10.2);
			s.push(20.2);
			s.push(30.2);
			System.out.println(s);
			System.out.println(s.peek());
			System.out.println(s.pop());
			
		HashSet<Integer>hs=new HashSet<>();
		hs.add(17);
		hs.add(13);
		hs.add(34);
		hs.add(23);
		System.out.println(hs);
		System.out.println(hs.size());
		for(Integer i:hs) {
			System.out.println(i);
		}
		System.out.println();
		Iterator<Integer> it=hs.iterator();//hasNext,next,remove
		while(it.hasNext()) {
			System.out.println(it.next()+" ");
		}
		boolean value1=hs.remove(34);
		System.out.println("Is 34 removed? "+value1);
		
		HashSet<Integer>hs2=new HashSet<>();
		hs2.add(245);
		hs2.add(231);
		hs2.add(123);
		hs.addAll(hs2);//union of sets
		System.out.println(hs);
		hs.retainAll(hs2);
		System.out.println(hs);
		
		
		//[2,3,5]
		//[1,3,5]
		//hs.removeAll(hs2);//remove all common elements
		
		List<Integer> li=new ArrayList<>(hs);
		TreeSet<Integer> en=new TreeSet<>();
		en.add(2);
		en.add(5);
		en.add(6);
		TreeSet<Integer> en1=new TreeSet<>();
		en1.add(1);
		en1.add(4);
		en1.add(8);
		en1.addAll(en);
		System.out.println(en1);
		System.out.println(en1.higher(4));
		System.out.println(en1.lower(3));
		System.out.println(en1.pollFirst());
		System.out.println(en1.pollLast());
	}

}
