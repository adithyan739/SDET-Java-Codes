package org.example;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListMergeSort {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		ArrayList<Integer> a1=new ArrayList<>();
		ArrayList<Integer> a2=new ArrayList<>();
		ArrayList<Integer> newList=new ArrayList<>();
		System.out.println("Enter the first arraylist:");
		for(int i=0;i<n;i++) {
			a1.add(sc.nextInt());
		}
		System.out.println("Enter the second arraylist:");
		for(int i=0;i<n;i++) {
			a2.add(sc.nextInt());
		}
//		for(Integer i:a1) {
//			System.out.println(i);
//		}
		newList=UseMainCodeArrayList.sortMergearraylist(a1,a2);
		for(int i=0;i<3;i++) {
			System.out.println(newList.get(i));
		}
//		for(Integer i:newList) {
//		System.out.println(i);
//	}
		
	}

}
