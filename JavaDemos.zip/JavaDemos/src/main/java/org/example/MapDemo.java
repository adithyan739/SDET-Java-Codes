package org.example;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;



public class MapDemo {
	public static void main(String[] args) {
		//create a map of generic type
		Map<Integer,String> map=new HashMap<>();
		//check map is empty or not
		boolean empty=map.isEmpty();
		System.out.println("Is hashmap empty "+empty);
		//adding entries
		map.put(24, "Yuvraj");
		map.put(22, "Dhoni");
		map.put(18, "Kohli");
		map.put(20, "Jadeja");
		map.put(20, "Bumrah");
		System.out.println(map);
		map.put(null, null);
		System.out.println(map);
		
		//removing key value pair
		map.remove(20);
		System.out.println(map);
		
		//replace
		map.replace(18, "Sachin");
		System.out.println(map);
		
		//iterate
		//creating an iterator object using iterator() method
		//entrySet() is a method that is used to get view of entries of a hashmap
		Iterator<Entry<Integer,String>> itr=map.entrySet().iterator();
		System.out.println("Iterating entries of hashmap");
		while(itr.hasNext()) {
			Object key=itr.next();
			System.out.println(key);
		}
		
		//keySet() is a method that is used to get view of keys of a hashmap
				Iterator<Integer> itr2=map.keySet().iterator();
				System.out.println("Iterating keys of hashmap");
				while(itr2.hasNext()) {
					Object key=itr2.next();
					System.out.println(key);
				}
				for(String keys:map.values()) {
					System.out.println(keys);
				}
				map.entrySet().stream().forEach(entry->{System.out.println(entry.getKey());});
				LinkedHashMap<String,Integer> lmap=new LinkedHashMap<>();
				lmap.put("leo",100);
				lmap.put("vikram",98);
				lmap.put("cidmoosa",96);
				lmap.put("extraction",94);
				System.out.println(lmap);
	}

}
