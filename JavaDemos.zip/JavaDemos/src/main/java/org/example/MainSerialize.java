package org.example;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class MainSerialize {
	public static void serializeToFile(Object ob, String filename) {
		try {
		//step1:open a file outputstream to create a file object on local disk
		//this file object is used to write the serialized bytes of object
		FileOutputStream filestream=new FileOutputStream(filename);
		//step2:create object outputstream, this class takes a file system
		//this class is responsible for converting the object to byte stream
		ObjectOutputStream obs=new ObjectOutputStream(filestream);
		//step3:objectoutputstream.writeobject takes an object and 
		//converting it to bytestream. Then it write the byte stream to file
		//using filestream that we created in step 1
		obs.writeObject(ob);
		obs.close();
		filestream.close();
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		SerializeRectangle sr=new SerializeRectangle(18,78);
		serializeToFile(sr, "rectserialized");
		
	}

}
