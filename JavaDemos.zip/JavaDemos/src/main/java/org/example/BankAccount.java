package org.example;

import java.util.Scanner;

public class BankAccount {
	double withdrawalAmount,depositAmount,bal;
	double InterestRate=9.5;
	void getdata() {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the deposit amount:");
	depositAmount=s.nextDouble();
	System.out.println("Enter the withdraw amount:");
	withdrawalAmount=s.nextDouble();
	}
	public void depositMoney() {
	System.out.println("Deposited amount: " + depositAmount);
	}
	public void withdrawalMoney() {
	System.out.println("Withdrawed amount: " + withdrawalAmount);
	bal=depositAmount-withdrawalAmount;
	System.out.println("Available Balanace = "+ bal);
	}
	}
	class NRIAccount extends BankAccount{
	public void applyFixedDeposit() {
	this.InterestRate=6.5;
	System.out.println("Interest rate of NRIaccount is "+InterestRate);
	}
	}
	class SeniorCitizen extends BankAccount{
	public void applyFixedDeposit() {
	super.InterestRate=10.5;
	System.out.println("Interest rate of NRIaccount is "+InterestRate);
	}
	}