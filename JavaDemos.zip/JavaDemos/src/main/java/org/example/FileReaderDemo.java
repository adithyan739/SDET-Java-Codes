package org.example;

import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {
	public static void main(String[] args) {
		char[] array=new char[100];
		try {
			FileReader input=new FileReader("C:\\JavaCodes\\JavaDemos\\src\\main\\java\\org\\example\\sample.txt");
			input.read(array);
			System.out.println("Data in the file:");
			System.out.println(array);
			
		}catch(IOException e) {
			e.getMessage();
		}
	}

}
