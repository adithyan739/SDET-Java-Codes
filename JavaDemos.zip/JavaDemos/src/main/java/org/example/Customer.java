package org.example;

import java.util.ArrayList;

public class Customer {
	String name;
	int balance;
	int id;
	public Customer(String name, int balance, int id) {
		super();
		this.name = name;
		this.balance = balance;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", balance=" + balance + ", id=" + id + "]";
	}
	public static void main(String[] args) {
		ArrayList<Customer> arr=new ArrayList<>();
		Customer c1=new Customer("Adhi",30000,2);
		Customer c2=new Customer("Yadhu",10000,3);
		Customer c3=new Customer("Shammi",50000,4);
		Customer c4=new Customer("Naina",10000,5);
		arr.add(c1);
		arr.add(c2);
		arr.add(c3);
		arr.add(c4);
		
		for(int i=0;i<arr.size();i++) {
			System.out.println(arr.get(i));
		}
	}

}
