package org.example;

public class OddNumberException {
	public static void trynumber(int n) throws IllegalArgumentException {

		try {

			checkEvenNumber(n);

		}

		catch (IllegalArgumentException e) {

			System.out.println(e.getMessage());

		}

	}

	public static void checkEvenNumber(int n) {

		if (n % 2 == 0) {

			System.out.println(n + " is even");

		}

		else

		{

			throw new IllegalArgumentException("Error : Try with another number");

		}

	}

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		int n = 18;

		trynumber(n);

		n = 7;

		trynumber(n);

	}

}
