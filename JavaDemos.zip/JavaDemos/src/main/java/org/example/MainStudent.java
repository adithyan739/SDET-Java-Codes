package org.example;

import java.util.Scanner;

public class MainStudent {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		
		StudentRead std=new StudentRead();
		
		System.out.println("Enter 3 marks:");
		std.m1=sc.nextInt();	
		std.m2=sc.nextInt();
		std.m3=sc.nextInt();
		System.out.println("Total: "+std.total());
		System.out.println("Average: "+std.avg());
	}
	
	

}
