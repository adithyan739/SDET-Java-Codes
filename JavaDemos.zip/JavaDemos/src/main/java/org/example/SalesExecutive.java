package org.example;

public class SalesExecutive implements SalaryCalculator {
	private double basicSalary;
	private double commission;
	
	public SalesExecutive(double basicSalary, double commission) {
		this.basicSalary = basicSalary;
		this.commission = commission;
	}

	@Override
	public double calculateSalary() {
		// TODO Auto-generated method stub
		return basicSalary+commission;
	}

}
