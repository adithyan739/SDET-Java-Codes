package org.example;

import java.util.Scanner;

public class ScoringArray {
	public static int scoreArr(int[] arr) {
		int score=0;
		
		for(int i=0;i<arr.length-2;i++) {
			int sum=0;
			int product=0;
			if((arr[i] + arr[i+1])%2==0) {
				score=score+5;
			}
			sum=arr[i]+arr[i+1]+arr[i+2];
				 
				if(sum%2!=0) {
					 product=arr[i]*arr[i+1]*arr[i+2];
					 if(product%2==0) {
						 score=score+10;
					 }
				}
			}
		
		return score;
		
	}
 	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println(scoreArr(arr));
	}

}
