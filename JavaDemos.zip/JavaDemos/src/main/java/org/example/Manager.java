package org.example;

public class Manager implements SalaryCalculator {
	private double basicSalary;
	private double allowance;

	public Manager(double basicSalary, double allowance) {
		this.basicSalary = basicSalary;
		this.allowance = allowance;
	}
	@Override
	public double calculateSalary() {
		// TODO Auto-generated method stub
		return basicSalary+allowance;
	}

}
