package org.example;

import java.io.File;
import java.io.IOException;

public class FileHandling {
	public static void main(String[] args) {
		File f=new File("C:\\JavaCodes\\JavaDemos\\src\\main\\java\\org\\example\\sample.txt");
		try {
			boolean value=f.createNewFile();
			if(value) {
				System.out.println("File created");
			}else {
				System.out.println("File already exist");
			}
		}catch(IOException e){
			e.getMessage();
		}

	}
}