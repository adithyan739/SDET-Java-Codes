package org.example;

import java.util.Scanner;

public class CoronaComputer {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the limit:");
		int n=s.nextInt();
		System.out.println("Enter the numbers:");
		int arr[]=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=s.nextInt();
		}
		System.out.println("Enter the number to shift:");
		int k=s.nextInt();
		for(int i=0;i<n;i++) {
			arr[i]=arr[i]>>k;
		}
		for(int i=0;i<n;i++)
		System.out.print(arr[i]+" ");
		
	}


}
