package org.example;

import java.io.File;

public class FileHandling2 {
	public static void main(String[] args) {
		File f=new File("C:\\JavaCodes\\JavaDemos\\src\\main\\java\\org\\example\\sample.txt");
		if(f.exists()) {
			System.out.println("Name of the file"+f.getName());
			System.out.println("The absolute path of the file"+f.getAbsolutePath());
			System.out.println("is file writable"+f.canWrite());
			System.out.println("is file readable"+f.canRead());
			System.out.println("The size of file"+f.length());
			
		}
		else {
			System.out.println("File does not exist");
		}
	}

}
