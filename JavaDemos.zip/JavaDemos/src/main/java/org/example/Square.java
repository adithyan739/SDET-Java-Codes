package org.example;

public class Square extends Shape {

	@Override
	public double calculateArea() {
		// TODO Auto-generated method stub
		double length=4.0,breadth=4.0;
		return length*breadth;
	}

}
