package org.example;

public class Vehicle {
	private int id;
	private String brand, model, rentalStatus;
	public Vehicle(int id, String brand, String model, String rentalStatus) {
		super();
		this.id = id;
		this.brand = brand;
		this.model = model;
		this.rentalStatus = rentalStatus;
	}
	
	public void rent() {
		this.rentalStatus="Rented";
		
	}
	public void returnVehicle() {
		this.rentalStatus="Available";
	}
	@Override
	public String toString() {
		return "Vehicle [id=" + id + ", brand=" + brand + ", model=" + model + ", rentalStatus=" + rentalStatus + "]";
	}
	

}
class Car extends Vehicle{
	private int seatingCapacity;
	private String fuelType;
	public Car(int id, String brand, String model, String rentalStatus, int seatingCapacity, String fuelType) {
		super(id, brand, model, rentalStatus);
		this.seatingCapacity = seatingCapacity;
		this.fuelType = fuelType;
	}
	
	public int getSeatingCapacity() {
		return seatingCapacity;
	}

	public void setSeatingCapacity(int seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	@Override
	public String toString() {
		return "Car [seatingCapacity=" + seatingCapacity + ", fuelType=" + fuelType + "]";
	}	
}
class Motorcycle extends Vehicle{
	private int engineDisplacement;

	public Motorcycle(int id, String brand, String model, String rentalStatus, int engineDisplacement) {
		super(id, brand, model, rentalStatus);
		this.engineDisplacement = engineDisplacement;
	}
	
	public int getEngineDisplacement() {
		return engineDisplacement;
	}

	public void setEngineDisplacement(int engineDisplacement) {
		this.engineDisplacement = engineDisplacement;
	}

	@Override
	public String toString() {
		return "Motorcycle [engineDisplacement=" + engineDisplacement + "]";
	}
}
class Truck extends Vehicle{
	private double  cargoCapacity;
	private int maxTowingCapacity;
	
	public Truck(int id, String brand, String model, String rentalStatus, double cargoCapacity, int maxTowingCapacity) {
		super(id, brand, model, rentalStatus);
		this.cargoCapacity = cargoCapacity;
		this.maxTowingCapacity = maxTowingCapacity;
	}

	public double getCargoCapacity() {
		return cargoCapacity;
	}

	public void setCargoCapacity(double cargoCapacity) {
		this.cargoCapacity = cargoCapacity;
	}

	public int getMaxTowingCapacity() {
		return maxTowingCapacity;
	}

	public void setMaxTowingCapacity(int maxTowingCapacity) {
		this.maxTowingCapacity = maxTowingCapacity;
	}
	
	
}
