package org.example;

import java.util.Arrays;
import java.util.Scanner;

public class UseMainAnagrams {
	static String getAnagram(String s1,String s2) {
		int n1=s1.length();
		int n2=s2.length();
		if(n1!=n2) {
			return "Not anagram";
		}
		else {
			char[] ch1 = s1.toCharArray();
			Arrays.sort(ch1);
			char[] ch2 = s1.toCharArray();
			Arrays.sort(ch2);
			for(int i=0;i<ch1.length;i++) {
				if(ch1[i]==ch2[i]) {
					return "Anagram";
				}
			}return "Not anagram";
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s1=sc.nextLine();
		String s2=sc.nextLine();
		System.out.println(getAnagram(s1,s2));
		
	}

}
