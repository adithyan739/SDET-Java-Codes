package org.example;

public class StringDemo {
	public static void main(String[] args) {
		String s1="Cat";
		String s2="Cat";
		String s3=new String("Cat");
		if(s1==s2) {
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}
		System.out.println(s1.length());
		System.out.println(s1.indexOf("a"));
		System.out.println(s1.equalsIgnoreCase(s3));
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.charAt(0));
		System.out.println(s1.concat(s3));
		System.out.println(s1.replace('C', 'B'));
		
		
		
	}

}
