package org.example;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class UserMainDuplicates {
	static String removeDuplicates(String str) {
		LinkedHashSet<Character>uniqueChars=new LinkedHashSet<>();
		for(char c:str.toCharArray()) {
			uniqueChars.add(c);
		}
		StringBuffer modifiedSentence=new StringBuffer();
		for(char c: uniqueChars) {
			modifiedSentence.append(c);
			}
		return modifiedSentence.toString();
	}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String str=s.nextLine();
		System.out.println(removeDuplicates(str));
		
		
	}

}
