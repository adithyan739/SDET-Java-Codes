package org.example;

public class InheritanceDemo {
	public static void main(String[] args) {
	// TODO Auto-generated method stub
	NRIAccount n1=new NRIAccount();
	SeniorCitizen s1=new SeniorCitizen();
	n1.getdata();
	n1.depositMoney();
	n1.withdrawalMoney();
	n1.applyFixedDeposit();
	s1.getdata();
	s1.depositMoney();
	s1.withdrawalMoney();
	s1.applyFixedDeposit();
	}
	}


