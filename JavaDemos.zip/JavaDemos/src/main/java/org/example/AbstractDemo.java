package org.example;

public class AbstractDemo {
	public static void main(String[] args) {
		Circle c=new Circle();
		Square s=new Square();
		c.setColor("Green");
		System.out.println(c.calculateArea());
		s.setColor("Red");
		System.out.println(s.calculateArea());
		
		
	}

}
