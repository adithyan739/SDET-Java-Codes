package org.example;

public class StringBufferDemo {
	public static void main(String[] args) {
		StringBuffer s1=new StringBuffer("Hello");
		StringBuffer s2=new StringBuffer(" World");
		System.out.println(s1.append(s2));
		System.out.println(s1.insert(5, "_Java"));
		s1.setCharAt(5,' ');
		System.out.println(s1);
		System.out.println(s1.charAt(6));
		
	}

}
