package org.example;

public class StudentRead {
	int m1,m2,m3,total,avg;
	public int total()
	{
		total=m1+m2+m3;
		return total;
		
	}
	public int avg()
	{
		avg=total/3;
		return avg;
		
	}
}

