package org.example;

public class MainDevisor {
	public static void main(String[] args) {
		AdvancedArithmetic mc=new MyCalculator();
		System.out.println(mc.devisorSum(6));
	}

}
