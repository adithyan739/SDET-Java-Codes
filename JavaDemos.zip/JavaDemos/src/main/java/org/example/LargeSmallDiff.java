package org.example;

import java.util.Scanner;

public class LargeSmallDiff {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size:");
		int n=s.nextInt();
		int arr[]=new int[n];
		if(n>=1) {
		System.out.println("Enter the elements:");
		
		for(int i=0;i<n;i++) {
			arr[i]=s.nextInt();
		}
		}
		else{
			System.out.println("Invalid input");
		}
		if(n==1) {
			System.out.println(arr[0]);
		}
		else {
		//UserMainCode obj=new UserMainCode();
		System.out.println(UserMainCode.getBigDiff(arr));
		}
	}
}
