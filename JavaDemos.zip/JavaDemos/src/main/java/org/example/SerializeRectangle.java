package org.example;

import java.io.Serializable;

public class SerializeRectangle implements Serializable {
	private double height;
	private double width;
	public SerializeRectangle(double height, double width) {
		this.height = height;
		this.width = width;
	}
	public double Area() {
		return height*width;
	}
	public double Perimeter() {
		return 2*(height+width);
	}
	

}
