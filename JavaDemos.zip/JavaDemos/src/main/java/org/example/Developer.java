package org.example;

public class Developer implements SalaryCalculator {
	private double basicSalary;
	private double bonus;
	
	public Developer(double basicSalary, double bonus) {
		this.basicSalary = basicSalary;
		this.bonus = bonus;
	}

	@Override
	public double calculateSalary() {
		// TODO Auto-generated method stub
		return basicSalary+bonus;
	}

}
