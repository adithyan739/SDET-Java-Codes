package org.example;

public class VehicleManagementSystem {
	public static void createVehicles() {

        Vehicle[] vehicles = new Vehicle[3];
        // Create a car
        vehicles[0] = new Car(1, "Toyota", "Camry","abc", 5, "Petrol");
        // Create a motorcycle
        vehicles[0]=new Motorcycle(0, null, null, null, 0);
        // Create a truck
        vehicles[0]=new Truck(0, null, null, null, 0, 0);
    }

    // Rent a vehicle

    public static void rentVehicle(int vehicleId) {
        // Find the vehicle in the array/collection and mark it as rented
        // Implementation depends on how the vehicles are stored (e.g., array, collection)
    }
    // Return a vehicle
    public static void returnVehicle(int vehicleId) {
        // Find the vehicle in the array and mark it as available (returned)
        // Implementation depends on how the vehicles are stored (e.g., array, collection)
    }
    // Display available vehicles

    public static void displayAvailableVehicles() {
        // Iterate through the array and display vehicles with "Available" status
        // Implementation depends on how the vehicles are stored (e.g., array, collection)
    }
    // Main method to execute the program
    public static void main(String[] args) {
        createVehicles();
        // Example usage
        rentVehicle(2);
        displayAvailableVehicles();
        returnVehicle(2);
        displayAvailableVehicles();
    }
}