package org.example;

public interface IPublicTransport {
	public void getNumberOfPeople();

}
