package org.example;

public class Circle extends Shape{

	@Override
	public double calculateArea() {
		// TODO Auto-generated method stub
		double r=5.0;
		return 3.14*r*r;
		
		
		
		
	}

}
