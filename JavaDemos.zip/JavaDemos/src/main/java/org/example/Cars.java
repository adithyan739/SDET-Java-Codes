package org.example;

public class Cars extends MotorisedVehicle implements IVehicle {

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void turnLeft() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		
	}

}
