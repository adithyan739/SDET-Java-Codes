package org.example;

public class Sample {
	
	public static void main(String[] args) {
		
		String sname="Adhi";
		int m1=68,m2=60,m3=70,m4=65,m5=80;
		String mob="7893671409";
		int sum=m1+m2+m3+m4+m5;
		int avg=sum/5;
		System.out.println("Name:"+sname);
		System.out.println("Phone number:"+mob);
		System.out.println("Total marks:"+sum);
		System.out.println("Average mark:"+avg);
		if(avg>=80) {
			System.out.println("Distinction");
		}
		else if(avg<80 && avg>=70) {
			System.out.println("First Class");
		}
		else if(avg<70 && avg>=60) {
			System.out.println("Second Class");
		}
		else{
			System.out.println("Failed");
		}
	}
	
	
}
