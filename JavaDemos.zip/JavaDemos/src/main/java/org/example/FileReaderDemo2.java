package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileReaderDemo2 {
	public static void main(String[] args) {
		File f=new File("C:\\JavaCodes\\JavaDemos\\src\\main\\java\\org\\example\\sample.txt");
		try {
			Scanner s=new Scanner(f);
			while(s.hasNextLine()) {
				String line=s.nextLine();
				System.out.println(line);
			}
		}catch(FileNotFoundException e){
			e.getMessage();
		}
	}

}
