package org.example;

public class MultidimentionalArray {
	public static void main(String[] args) {
		int[][] matrixA= {
				{1,6,8},
				{5,8,0},
				{2,5,9},
				
		};
		int[][] matrixB= {
				{7,9,2},
				{1,0,6},
				{4,3,5}
		};
		int[][] matrixC = new int[3][3];
		for(int i=0;i<matrixA.length;i++) {
			for(int j=0;j<matrixA[0].length;j++) {
				System.out.print(matrixA[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println();
		for(int i=0;i<matrixB.length;i++) {
			for(int j=0;j<matrixB[0].length;j++) {
				System.out.print(matrixB[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println();
		for(int i=0;i<matrixC.length;i++) {
			for(int j=0;j<matrixC[0].length;j++) {
				System.out.print(matrixA[i][j]+matrixB[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println();
		int[][] matrixD= {
				{2,4,6},
				{4,5,7}
		};
//		int[][] transpose=new int[3][2];
//		for(int i=0;i<3;i++) {
//			for(int j=0;j<2;j++) {
//				transpose[j][i]=matrixD[i][j];
//			}
//			System.out.println();
//		}
		System.out.println();
		for(int i=0;i<=matrixD.length;i++) {
			for(int j=0;j<matrixD.length;j++) {
				System.out.print(matrixD[j][i]+" ");
			}
			System.out.println();
		}
		System.out.println();
//		
//		for(int i=0;i<transpose.length;i++) {
//			for(int j=0;j<transpose[0].length;j++) {
//				System.out.print(transpose[i][j]+" ");
//			}
//			System.out.println();
//		}
	}

}
