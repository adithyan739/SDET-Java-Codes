
package org.example;
public class UserMainCode {
	public static int getBigDiff (int arr[]) {
		int max_val = arr[0];
		int min = arr[0];
		for(int i = 1; i < arr.length; i++)
		{
		if(arr[i] > max_val)
		max_val = arr[i];
		else if(arr[i] < min)
		min = arr[i];
		}
		return max_val-min;
		}

		

	}
