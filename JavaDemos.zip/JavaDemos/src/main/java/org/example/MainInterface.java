package org.example;

public class MainInterface {
	public static void main(String[] args) {
		IVehicle vehobj=new Cars();
		vehobj.drive();
		vehobj.brake();
		
		Cars c=new Cars();
		c.checkMotor();
		
		IVehicle vehobj1=new Train();
		vehobj1.drive();
		vehobj1.brake();
		
		IPublicTransport pubobj=new Train();
		pubobj.getNumberOfPeople();
		//Train t=new Train();
		
	}
	

}
