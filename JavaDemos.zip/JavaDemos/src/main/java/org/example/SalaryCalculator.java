package org.example;

public interface SalaryCalculator {

	public double calculateSalary();

}
