package org.example;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Scanner;

public class FileWriterDemo {
	public static void main(String[] args) {
		try {
			OutputStream fwriter= new FileOutputStream("C:\\JavaCodes\\JavaDemos\\src\\main\\java\\org\\example\\sample.txt");
			Writer fwriteWriter=new OutputStreamWriter(fwriter);
			fwriteWriter.write("Writing using OutputStreamWriter");
			fwriteWriter.close();
		}catch(Exception e) {
			e.getMessage();
	}
	
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		try {
//		FileWriter fw=new FileWriter("C:\\JavaCodes\\JavaDemos\\src\\main\\java\\org\\example\\sample.txt");
//		System.out.println("Enter the content:");
//		fw.write(sc.nextLine());
//		fw.close();	
//		
//	}catch(IOException e) {
//		System.out.println("Error while writing");
//		e.printStackTrace();
//	}
	}
}
