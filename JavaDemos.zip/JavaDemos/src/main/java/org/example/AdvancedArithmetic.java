package org.example;

public interface AdvancedArithmetic {
	public int devisorSum(int n);

}
