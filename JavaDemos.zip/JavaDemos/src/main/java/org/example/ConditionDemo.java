package org.example;

public class ConditionDemo {
	public static void main(String[] args) {
		int i=1;
		while(i<5) {
			System.out.println(i);
			i++;
		}
		int j=10;
		System.out.println("Reversed");
		while(j>1) {
			
			System.out.println(j);
			j--;
		}
	}
}
