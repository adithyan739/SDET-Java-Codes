package org.example;

import java.util.Scanner;

public class RemoveEvenVow {
	public static String removeVowels(String str) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < str.length(); i++) {
			if (i % 2 == 0) {
				sb.append(str.charAt(i));
			} else {
				if (str.charAt(i) != 'a' && str.charAt(i) != 'e' && str.charAt(i) != 'i' && str.charAt(i) != 'o'
						&& str.charAt(i) != 'u') {
					sb.append(str.charAt(i));
				}
			}
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		String str = s.nextLine();
		System.out.println(removeVowels(str));
	}
}