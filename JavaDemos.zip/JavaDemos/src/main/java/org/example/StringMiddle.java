
package org.example;

import java.util.Scanner;

public class StringMiddle {
	static String getMiddleChars (String str) {
		StringBuffer sb=new StringBuffer();
		if(str.length()%2==0) {
			sb.append(str.substring((str.length()/2)-1, (str.length()/2)+1));
		}
		return sb.toString();
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		System.out.println(getMiddleChars(str));
		
	}

}
