package org.testing;

import java.util.StringTokenizer;

public class Stringdemos {
	// Online Java Compiler
	// Use this editor to write, compile and run your Java code online

		/*
		 * This method will split the query string based on space into an array of words
		 * and display it on console
		 */

		public String[] getSplitStrings(String queryString) {
			//StringTokenizer s=new StringTokenizer(queryString);
			String[] str=queryString.split(" ");
			return str;
		}
	    public static void main(String[] args) {
	    	Stringdemos d=new Stringdemos();
	        String queryString="Select * from table";
	        String s[]=d.getSplitStrings(queryString);
	        
	        System.out.println(s[0]);
	    }
	}


