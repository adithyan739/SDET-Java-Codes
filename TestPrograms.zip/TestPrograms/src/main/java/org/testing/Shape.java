package org.testing;

public class Shape {
	String color;
	public String getColor() {
		return color;
	}
	public double getArea() {
		double area=0.0;
		return area;
	}
}
class Circle extends Shape{
	double radius;
	public double getRadius() {
		return radius;
	}
	public double getArea() {
		return 3.14 * (radius*radius);
	}
}
class Rectangle extends Shape{
	double length;
	double width;
	public double getLength() {
		return length;
	}
	public double getWidth() {
		return width;
	}
	public double getArea() {
		return length*width;
	}	
}