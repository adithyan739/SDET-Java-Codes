package org.testing;

public class Wallet {
	private double balance;
	public Wallet() {
		balance=0.0;
	}
	public void addMoney(double amount) {
		balance+=amount;
	}
	public void spendMoney(double amount) {
		if(amount<0) {
			throw new IllegalArgumentException("Amount can't be negative");
		}
		if(amount>balance) {
			throw new IllegalArgumentException("Insufficient funds");
		}
		balance-=amount;
	}
	public double getBalance() {
		return balance;
	}

}
