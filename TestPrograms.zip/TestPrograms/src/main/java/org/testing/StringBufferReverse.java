package org.testing;

public class StringBufferReverse {
	public String reverseString(String str) {
		StringBuilder reversed=new StringBuilder(str);
		return reversed.reverse().toString();
	}

}
