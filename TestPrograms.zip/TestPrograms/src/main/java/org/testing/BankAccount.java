package org.testing;

public class BankAccount {
	private String accountHolder;
	private double balance;
	public BankAccount(String accountHolder, double balance) {
		super();
		this.accountHolder = accountHolder;
		this.balance = balance;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public double getBalance() {
		return balance;
	}
	public void deposit(double amount) {
		balance+=amount;
	}
	public boolean withdraw(double amount) {
		if(amount<0) {
			throw new IllegalArgumentException("Amount can't be negative");
		}
		if(amount<=balance) {
			balance-=amount;
			return true;
		}
		return false;
	}
	

}
