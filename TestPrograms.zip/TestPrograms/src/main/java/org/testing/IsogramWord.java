package org.testing;

import java.util.Scanner;

public class IsogramWord {
	public static String isogram(String str) {
//		int space=0,hiph=0;
		 str=str.replaceAll("\\s", "");
		char[] ch=str.toCharArray();
		for(int i=0;i<str.length();i++) {
			for(int j=i+1;j<str.length();j++)
				if(ch[i]==ch[j] ) {
				return "Not isogram";
				}
				
		}return "Isogram";
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		System.out.println(isogram(str));
	}

}
