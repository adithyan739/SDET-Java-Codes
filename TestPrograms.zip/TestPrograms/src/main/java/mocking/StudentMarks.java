package mocking;

public class StudentMarks {
	public Database database;
	public StudentMarks(Database database) {
		this.database=database;
	}
	public int getTotalMarks() {
		int mathMarks=database.getMathmarks();
		int scienceMarks=database.getSciencemarks();
		int englishMarks=database.getEnglishmarks();
		return mathMarks+scienceMarks+englishMarks;
	}

}
