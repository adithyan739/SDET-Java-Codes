package mocking;

public interface Database {
	int getMathmarks(); 
	int getSciencemarks(); 
	int getEnglishmarks(); 
	

}
