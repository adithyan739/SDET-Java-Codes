package mocking;

public class MockDatabse implements Database {
	
	public int getMathmarks() {
		return 80;
	}
	
	public int getSciencemarks() {
		return 90;
	}
	
	public int getEnglishmarks() {
		return 85;
	}

}
