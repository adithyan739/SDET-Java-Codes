package org.testing;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BankAccountTest {
	private BankAccount bankAccount;
	
	@BeforeEach
	public void setUp() {
		bankAccount=new BankAccount("John Wick", 1000.00);
	}
	
	@Test
	public void testGetAccountHolder() {
		//test account holder
		String holder=bankAccount.getAccountHolder();
		assertEquals("John Wick", holder);
	}
	
	@Test
	public void testGetBalance() {
		double balance=bankAccount.getBalance();
		assertEquals(1000.00, balance);
	}
	
	@Test
	public void testGetDeposit() {
		bankAccount.deposit(500.00);
		double newbalance=bankAccount.getBalance();
		assertEquals(1500.00, newbalance);
	}
	
	@Test
	public void testWithdrawSufficientFunds() {
		boolean success=bankAccount.withdraw(700.00);
		assertTrue(success);
		//test the balance here same like previous method 
	}
	
	@Test
	public void testWithdrawInsufficientFunds() {
		boolean fail=bankAccount.withdraw(1500.00);
		assertFalse(fail);
		double balance=bankAccount.getBalance();
		assertEquals(1000.00, balance);
		
	}
	
	@Test
	public void testWithdrawNegativeAmount() {
		assertThrows(IllegalArgumentException.class, ()->{
		bankAccount.withdraw(-200);});
	}
}
