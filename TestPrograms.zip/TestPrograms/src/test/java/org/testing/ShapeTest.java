package org.testing;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ShapeTest {
	Shape shape;
	
	@BeforeEach
	public void setUp() {
		shape=new Shape();
	}
	
	@Test
	public void getTestColor() {
		String clr=shape.getColor();
		
	}

}
