package org.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class StringBufferReverseTest {
	
	@Test
	public void testReverse() {
		StringBufferReverse rev=new StringBufferReverse();
		String input="Hello World";
		String expected="dlroW olleH";
		String reversed=rev.reverseString(input);
		assertEquals(expected, reversed);
	}

}
