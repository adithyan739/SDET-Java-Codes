package org.testing;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class StringReverseTest {
	
	@Test
	public void sortArrayTest() {
		StringReverse s=new StringReverse();
		String str=s.reverseString("Reverse");
		
		assertEquals("esreveR", str);
	}


}
