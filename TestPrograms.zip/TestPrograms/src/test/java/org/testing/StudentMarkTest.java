package org.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import mocking.Database;
import mocking.StudentMarks;

@ExtendWith(MockitoExtension.class) 
//@ExtendWith(MockitoExtension.class) enables the mockito extension for JUnit 5
public class StudentMarkTest {
	
	@Mock 
	//mock annotation is used to mock the database dependency
	public Database databasemock;
	
	@InjectMocks 
	//injectmock annotation is used to inject the mocked dependency
	//into the StudentMarks object being tested
	public StudentMarks studentmarks;
	
	@Test
	public void testGettotalmarks() {
		//Arrange
		when(databasemock.getMathmarks()).thenReturn(80);
		when(databasemock.getSciencemarks()).thenReturn(90);
		when(databasemock.getEnglishmarks()).thenReturn(85);
		//Act
		int totalmarks=studentmarks.getTotalMarks();
		//Assert
		assertEquals(255, totalmarks);
	}
	

}
