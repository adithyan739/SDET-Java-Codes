package org.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class WalletTest {
	private Wallet wallet;

	@BeforeEach
	public void setUp() {
		wallet = new Wallet();
	}

	@Test
	public void testGetAddMoney() {
		wallet.addMoney(500.00);
		double newbalance = wallet.getBalance();
		assertEquals(500.00, newbalance);
	}

	@Test
	public void TestspendMoney() {
		wallet.addMoney(500);
		wallet.spendMoney(200);
		double balance = wallet.getBalance();
		assertEquals(300, balance);
	}

	@Test
	public void testNegativespendMoney() {
		assertThrows(IllegalArgumentException.class, () -> {
			wallet.spendMoney(-200.00);
		});
	}

	@Test
	public void testInsufficientspendMoney() {
		assertThrows(IllegalArgumentException.class, () -> {
			wallet.spendMoney(600.00);
		});
	}	
}


