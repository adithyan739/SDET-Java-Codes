package testcasesAPI;

import org.testng.Assert;
import org.testng.annotations.Test;

import endpoints.AuthorEndPoints;
import io.restassured.response.Response;

import payload.AuthorModel;
import utilities.DataProviders;

public class DataDrivenTest {

	
	AuthorModel auth;
	@Test(priority = 1, dataProvider = "data", dataProviderClass = DataProviders.class)
	public void testPostAuthor(String id, String idbook, String firstname, String lastname) {
		AuthorModel auth = new AuthorModel();
		auth.setId(id);
		auth.setIdBook(idbook);
		auth.setFirstName(firstname);
		auth.setLastName(lastname);
		Response response = AuthorEndPoints.createAuthor(auth);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 2, dataProvider = "AuthorId", dataProviderClass = DataProviders.class)
	public void testGetAuthorId(String id) {
	
		Response response = AuthorEndPoints.getAuthorId(id);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}
	
	@Test(priority = 3, dataProvider = "AuthorBookId", dataProviderClass = DataProviders.class)
	public void testGetAuthorBookId(String idbook) {

		Response response = AuthorEndPoints.getAuthorBookId(idbook);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 4, dataProvider = "AuthorId", dataProviderClass = DataProviders.class)
	public void testUpdateByAuthorId(String id) {
		AuthorModel auth = new AuthorModel();
		auth.setId(id);
		auth.setIdBook("13");
		auth.setFirstName("Firstname updated");
		auth.setLastName("Lastname updated");
		Response response = AuthorEndPoints.updateAuthor(id,auth);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
		
//		Response responseafterupdate = AuthorEndPoints.getAuthorId(id);
//		responseafterupdate.then().log().all();
//		Assert.assertEquals(responseafterupdate.getStatusCode(), 200);
	}
	
	@Test(priority = 5, dataProvider = "AuthorId", dataProviderClass = DataProviders.class)
	public void testDeleteByAuthorId(String id) {
		Response response = AuthorEndPoints.deleteAuthor(id);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}
}