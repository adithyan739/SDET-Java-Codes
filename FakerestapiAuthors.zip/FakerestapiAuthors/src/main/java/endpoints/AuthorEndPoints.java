package endpoints;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.AuthorModel;

//create to perform CRUD operations in user api
public class AuthorEndPoints {
	public static Response createAuthor(AuthorModel payload) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().baseUri(Routes.baseuri).basePath(Routes.post_basePath)
				.contentType("application/json").accept(ContentType.JSON).body(payload).when().post();
		return response;
	}

	public static Response getAuthorId(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().baseUri(Routes.baseuri).basePath(Routes.get_basePath1)
				.pathParam("id", id).contentType("application/json").accept(ContentType.JSON).when().get();
		return response;
	}
	public static Response getAuthorBookId(String idBook) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().baseUri(Routes.baseuri).basePath(Routes.get_basePath2)
				.pathParam("idBook", idBook).contentType("application/json").accept(ContentType.JSON).when().get();
		return response;
	}

	public static Response deleteAuthor(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().baseUri(Routes.baseuri).basePath(Routes.delete_basePath)
				.pathParam("id", id).contentType("application/json").accept(ContentType.JSON).when()
				.delete();
		return response;
	}

	public static Response updateAuthor(String id, AuthorModel payload) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = RestAssured.given().baseUri(Routes.baseuri).basePath(Routes.update_basePath)
				.pathParam("id", id).contentType("application/json").accept(ContentType.JSON).body(payload)
				.when().put();
		return response;
	}

}
