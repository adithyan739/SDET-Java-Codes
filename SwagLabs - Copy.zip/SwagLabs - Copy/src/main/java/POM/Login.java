package POM;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import Base.BaseUI;

public class Login extends BaseUI {
	WebDriver driver;

	public Login(WebDriver driver) {
		this.driver = driver;
	}

	// locators
	By username = getlocator("username_name");
	By password = getlocator("password_name");
	By submit = getlocator("submit_name");

	// elements as methods
	public void userName(String user) {
		sendtext(username, user);
		logger.log(Status.INFO, "username is entered");
	}

	public void passWord(String pass) {
		isElementPresent(password, Duration.ofSeconds(15));
		sendtext(password, pass);
		logger.log(Status.INFO, "password is entered");
	}

	public void submit() {
		clickOn(submit);
		logger.log(Status.INFO, "submit is clicked");
	}



}
