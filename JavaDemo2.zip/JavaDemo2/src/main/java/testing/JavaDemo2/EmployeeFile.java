package testing.JavaDemo2;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class EmployeeFile {
	public static void main(String[] args) {
		try {
			FileReader f = new FileReader("C:\\JavaCodes\\JavaDemo2\\src\\main\\java\\testing\\JavaDemo2\\Data.csv");
			Scanner sc = new Scanner(f);
			Scanner s = new Scanner(System.in);
			String city=s.nextLine();
			while (sc.hasNextLine()) {			
					String line = sc.nextLine();
					if(line.contains(city)) {
						System.out.println(line);
					}
				}
			} catch (FileNotFoundException e) {
			e.getMessage();
		}

	}

}