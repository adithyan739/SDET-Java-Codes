$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"a8665715-0d56-42d6-a0b0-b1b6af545411","feature":"Itdepot page feature","scenario":"Depot page title","start":1691553157845,"group":1,"content":"","tags":"","end":1691553176638,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});