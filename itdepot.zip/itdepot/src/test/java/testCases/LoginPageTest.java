package testCases;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.BaseUI;
import POM.LoginPage;

public class LoginPageTest extends BaseUI{
	private WebDriver driver;
	String[][] data;

	@BeforeTest
	public void setUp() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}
	
	@Test
	public void pageTest() {
		LoginPage login=new LoginPage(driver);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(login.category).isDisplayed());

		
	});
		login.cat_click();
	
	login.graphics_click();
	String expectedUrl="https://www.theitdepot.com/products-Graphic+Cards_C45.html";
	String actualUrl=driver.getCurrentUrl();
	SoftAssertions.assertSoftly(softAssertions->{
	softAssertions.assertThat(expectedUrl.equalsIgnoreCase(actualUrl)).isTrue();
	});
	}
}
