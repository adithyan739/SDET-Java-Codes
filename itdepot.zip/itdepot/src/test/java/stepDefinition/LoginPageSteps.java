package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import Base.BaseUI;
import Base.BrowserConfig;
import POM.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPageSteps extends BaseUI{
	public static String title;
	public WebDriver driver=BrowserConfig.getchromeBrowser();
	public LoginPage loginpage = new LoginPage(driver);
	
	@Given("user is on itdpot page")
	public void user_is_on_itdpot_page() {
		driver.get("https://www.theitdepot.com/");
	}

	@When("user gets on the title of the page")
	public void user_gets_on_the_title_of_the_page() {
		title = loginpage.getLoginPageTitle();
		System.out.println(title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String titlename) {
		title = loginpage.getLoginPageTitle();
		Assert.assertEquals(title, titlename);
	}

}
