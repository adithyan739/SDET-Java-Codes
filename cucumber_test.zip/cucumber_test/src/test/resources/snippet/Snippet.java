package snippet;

public class Snippet {
	screenshot.dir=test-output/
	screenshot.rel.path=../
	extent.reporter.pdf.start=true
	extent.reporter.pdf.out=TestOutput/PdfReport/ExtentPdf.pdf
	extent.reporter.spark.vieworder=dashboard,test,category,exception,author,device,log
}

