package Testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.BrowserConfig;
import POM.Register;


public class RegisterTest {
	WebDriver driver;
	@BeforeTest
	public void setup() {
		driver=BrowserConfig.getBrowser();	
		driver.navigate().to("https://parabank.parasoft.com/parabank/index.htm");
//		Register reg=new Register(driver);
//		reg.regClick();
		driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/p[2]/a")).click();
	}
	
	@Test(priority=0)
	public void firstnameTest() {
		Register reg=new Register(driver);
		reg.firstName("Adhi");	
	}
	
	@Test(priority=1)
	public void lastnameTest() {
		Register reg=new Register(driver);
		reg.lastName("K");	
	}
	
	@Test(priority=2)
	public void adressTest() {
		Register reg=new Register(driver);
		reg.address("Kallattu House,Angamaly");	
	}
	
	@Test(priority=3)
	public void cityTest() {
		Register reg=new Register(driver);
		reg.city("Ernakulam");	
	}
	
	@Test(priority=4)
	public void stateTest() {
		Register reg=new Register(driver);
		reg.state("Kerala");	
	}
	
	@Test(priority=5)
	public void zipcodeTest() {
		Register reg=new Register(driver);
		reg.zipCode("683577");	
	}
	
	@Test(priority=6)
	public void phoneTest() {
		Register reg=new Register(driver);
		reg.phoneNumber("7558802442");	
	}
	
	@Test(priority=7)
	public void SSNTest() {
		Register reg=new Register(driver);
		reg.SSN("1936");	
	}
	@Test(priority=8)
	public void usernameTest() {
		Register reg=new Register(driver);
		reg.userName("adhi");	
	}
	
	@Test(priority=9)
	public void passwordTest() {
		Register reg=new Register(driver);
		reg.passWord("adhi123");
	}
	
	@Test(priority=10)
	public void rpasswordTest() {
		Register reg=new Register(driver);
		reg.rpassWord("adhi123");
	}
	
	@Test(priority=11)
	public void submitTest() {
		Register reg=new Register(driver);
		reg.register();
		
	}
	
	@AfterTest
	public void teardown() {
		driver.close();
	}


}
