package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Register {
	WebDriver driver;

	public Register(WebDriver driver) {
		this.driver = driver;
	}

	// locators
	//By registerclick = By.xpath("//a[@href='register.htm']");
	By firstname = By.id("customer.firstName");
	By lastname = By.id("customer.lastName");
	By address = By.id("customer.address.street");
	By city = By.id("customer.address.city");
	By state = By.id("customer.address.state");
	By zipcode = By.id("customer.address.zipCode");
	By phone = By.id("customer.phoneNumber");
	By SSN = By.id("customer.ssn");
	By username = By.id("customer.username");
	By password = By.id("customer.password");
	By rpassword = By.id("repeatedPassword");
	By register = By.xpath("//input[@value='Register']");

	// elements as methods
//	public void regClick() {
//
//		driver.findElement(By.xpath("//a[@href='register.htm']")).click();
//	}
	
	public void firstName(String frstname) {

		WebElement fname = driver.findElement(firstname);
		if (fname.isEnabled() == true)
			fname.sendKeys(frstname);
	}
	
	public void lastName(String lstname) {

		WebElement lname = driver.findElement(lastname);
		if (lname.isEnabled() == true)
			lname.sendKeys(lstname);
	}

	public void address(String add) {

		WebElement addr = driver.findElement(address);
		if (addr.isEnabled() == true)
			addr.sendKeys(add);
	}

	public void city(String ct) {

		WebElement c = driver.findElement(city);
		if (c.isEnabled() == true)
			c.sendKeys(ct);
	}
	
	public void state(String st) {

		WebElement s = driver.findElement(state);
		if (s.isEnabled() == true)
			s.sendKeys(st);
	}

	public void zipCode(String zip) {

		WebElement zcode = driver.findElement(zipcode);
		if (zcode.isEnabled() == true)
			zcode.sendKeys(zip);
	}

	public void phoneNumber(String phn) {

		WebElement ph = driver.findElement(phone);
		if (ph.isEnabled() == true)
			ph.sendKeys(phn);
	}
	public void SSN(String ssn) {

		WebElement sn = driver.findElement(SSN);
		if (sn.isEnabled() == true)
			sn.sendKeys(ssn);
	}

	public void userName(String user) {

		WebElement uname = driver.findElement(username);
		if (uname.isEnabled() == true)
			uname.sendKeys(user);
	}


	public void passWord(String pass) {
		WebElement pword = driver.findElement(password);
		if (pword.isEnabled() == true)
			pword.sendKeys(pass);
	}
	
	public void rpassWord(String rpass) {
		WebElement rpword = driver.findElement(rpassword);
		if (rpword.isEnabled() == true)
			rpword.sendKeys(rpass);
	}

	public void register() {
		WebElement regstr = driver.findElement(register);
		regstr.click();
	}

}
