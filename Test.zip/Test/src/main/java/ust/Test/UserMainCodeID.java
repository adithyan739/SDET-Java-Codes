package ust.Test;

import java.util.Scanner;
import java.util.StringTokenizer;

public class UserMainCodeID {
	
	public static String validateIDLocations(String id,String loc) {
		String locfirstthree=loc.substring(0,3);
		StringTokenizer t = new StringTokenizer(id, "-");
		String s1 = t.nextToken();
		String s2 = t.nextToken();
		String s3 = t.nextToken();
		if (s1.equals("UST") && s2.equals(locfirstthree) && s3.matches("[0-9]{4}")) {
			return "Valid";
			}
			return "Invalid Id";
			}
	
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String id=s.next();
		String loc=s.next();
		
		System.out.println(validateIDLocations(id, loc));
		
	}

}
