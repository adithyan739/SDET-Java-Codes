package ust.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SubtitleCount {

	public static void wordCount(String str) {
		//removing punctuation and convert to lowercase
		String s1 = str.replaceAll("[^A-Za-z0-9\\s]", "").toLowerCase();
		
		//split the subtitle into words
		String[] words = s1.split("\\s+");
		
		//count the occurrences of each word
		Map<String,Integer> wordCountMap=new HashMap<>();
		for(String word: words) {
			int count=wordCountMap.getOrDefault(word, 0);
			wordCountMap.put(word, count+1);
		}
		
		//print the word count results
		for(Map.Entry<String, Integer> entry: wordCountMap.entrySet()) {
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String str = s.nextLine();
		wordCount(str);
	}

}
