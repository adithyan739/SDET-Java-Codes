package ust.Test;

import java.util.Scanner;

public class BankAccount1 {
	int account_number;
	String account_holder_name;
	static double balance;
	double interest_rate;
	public BankAccount1(int account_number, String account_holder_name, double balance, double interest_rate) {
		super();
		this.account_number = account_number;
		this.account_holder_name = account_holder_name;
		this.balance = balance;
		this.interest_rate = interest_rate;
	}

	public void depositMoney(double depositAmount) {
	System.out.println("Deposited amount: " + depositAmount);
	}
	public void withdrawalMoney(double withdrawalAmount) {
	System.out.println("Withdrawed amount: " + withdrawalAmount);
	}
	public void interestEarned(double interest) {
		System.out.println("Interest earned: "+interest);
	}
	public static void balanceAmount(double withdrawalAmount,double depositAmount,double interest_rate) {
		balance=depositAmount-withdrawalAmount+interest_rate;
		System.out.println("Available Balanace = "+ balance);
		}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int account_number;
		String account_holder_name;
		double interest_rate=9.2;
		
		System.out.println("Enter the account number:");
		account_number=s.nextInt();
		System.out.println("Enter the account holder name:");
		account_holder_name=s.next();
		System.out.println("Enter the deposit amount:");
		double depositAmount=s.nextDouble();
		System.out.println("Enter the withdraw amount:");
		double withdrawalAmount=s.nextDouble();
		BankAccount1 obj=new BankAccount1(account_number, account_holder_name, withdrawalAmount, interest_rate);
		obj.depositMoney(depositAmount);
		obj.withdrawalMoney(withdrawalAmount);
		obj.interestEarned(interest_rate);
		balanceAmount(withdrawalAmount,depositAmount,interest_rate);
		
	}

}
