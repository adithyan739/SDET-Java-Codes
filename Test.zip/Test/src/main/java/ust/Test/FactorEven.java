package ust.Test;

import java.util.Scanner;

public class FactorEven {
	
	public static void calculateFactor(int num) {
		if(num%3==0) {
			System.out.print("Pling");
		}
		if(num%5==0) {
			System.out.print("Plang");
		}
		else if(num%7==0) {
			System.out.print("Plong");
		}
		else {
			System.out.println(num);
		}	
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		calculateFactor(num);
	}

}
