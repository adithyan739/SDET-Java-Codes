package ust.Test;

import java.util.Scanner;

public class LargestSubsequence {

		static int lis(int arr[], int n)
		{
			int lis[] = new int[n];
			int i, j, max = 0;

			for (i = 0; i < n; i++)
				lis[i] = 1;
			for (i = 1; i < n; i++)
				for (j = 0; j < i; j++)
					if (arr[i] > arr[j] && lis[i] < lis[j] + 1)
						lis[i] = lis[j] + 1;
			for (i = 0; i < n; i++)
				if (max < lis[i])
					max = lis[i];

			return max;
		}
		public static void main(String args[])
		{
			Scanner s=new Scanner(System.in);
			System.out.println("Enter the number of elements:");
			int n=s.nextInt();
			int[] arr=new int[n+1];
			System.out.println("Enter Elements : ");
			for(int i=0;i<n;i++)
			{
			arr[i]=s.nextInt();
			}
			System.out.println(lis(arr, n));
		}
	}
	