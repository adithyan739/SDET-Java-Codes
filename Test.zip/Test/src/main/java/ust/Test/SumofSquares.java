package ust.Test;

import java.util.Scanner;

public class SumofSquares {
	
	public static void calculateSquare(int n) {
		int SquareSum=0;
		int SumSquare=0;
		for(int i=1;i<=n;i++) {
			SquareSum=SquareSum+(i*i);
			SumSquare=SumSquare+i;
		}
		int newSumSquare=SumSquare*SumSquare;
		int result=newSumSquare-SquareSum;
		System.out.println(SquareSum);
		System.out.println(newSumSquare);
		System.out.println(result);
		
		
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		calculateSquare(n);
		
	}

}
